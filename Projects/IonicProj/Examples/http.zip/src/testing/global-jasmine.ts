import jasmineRequire from 'jasmine-core/lib/jasmine-core/jasmine.js';

window['jasmineRequire'] = jasmineRequire;
